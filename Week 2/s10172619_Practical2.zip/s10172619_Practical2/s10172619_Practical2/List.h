// List.h - - Specification of List ADT
#pragma once
#include <iostream>
using namespace std;

#include "Person.h" // 1 just addded

const int MAX_SIZE = 100;
typedef Person ItemType; // 2 change integer to Person
//Makes it easier 
//typedef means that the type(which is object) can be represented by another variable.

class List
{
private:
	ItemType items[MAX_SIZE];
	//aka it is == Person items[Max_SIZE];
	// items is the name of the array while Max_Size is the size of the array.
	// items[Max_SIZE] has a datatype of "Person" which is an object class and it stores "Person" objects in the array!
	int      size;

public:

	// constructor
	List::List();

	// add an item to the back of the list (append)
	// pre : size < MAX_SIZE
	// post: item is added to the back of the list
	//       size of list is increased by 1
	bool List::add(ItemType item);

	// add an item at a specified position in the list (insert)
	// pre : 1 <= index <= size && size < MAX_SIZE
	// post: item is added to the specified position in the list
	//       size of list is increased by 1
	bool List::add(int index, ItemType item);

	// remove an item at a specified position in the list
	// pre : 1 <= index <= size
	// post: item is removed the specified position in the list
	//       size of list is decreased by 1
	void List::remove(int index);

	// get an item at a specified position of the list (retrieve)
	// pre : 1 <= index <= size
	// post: none
	ItemType List::get(int index);

	// check if the list is empty
	// pre : none
	// post: none
	// return true if the list is empty; otherwise returns false
	bool List::isEmpty();

	// check the size of the list
	// pre : none
	// post: none
	// return the number of items in the list
	int List::getLength();

	void List::print();

	void List::replace(int index, ItemType item);

	int List::searchForRemove(string , string);
	// iterate each object in the list
	// check if the name and the number of the person object exists
	// pre : non
	//post : return the index of the object in the list if it exists or return -1 if the object does not exist.

	void List::search(string userInput);
	// iterate each object in the list
	// pre : non
	//post : return the index of the object
};
