// List.cpp - Implementation of List ADT using Array
#include "stdafx.h"
#include "List.h"  // header file

// constructor
List::List() { size = 0; }
// i can access the private attribute which is items[Max_Size] 
// which is the array!

// add an item to the back of the list (append)
bool List::add(ItemType item) //ItemType == Person
{
	bool success = size < MAX_SIZE;
	if (success)
	{
		items[size] = item;    // add to the end of the list
		size++;                // increase the size by 1
		
	}
	return success;
}

// add an item at a specified position in the list (insert)
bool List::add(int index, ItemType item)
{
	bool success = (index >= 1) && (index <= size + 1) && (size < MAX_SIZE);
	if (success)
	{  // make room for the item by shifting all items at
	   // positions >= index toward the end of the
	   // List (no shift if index == size + 1)
		for (int pos = size; pos >= index; pos--)
			items[pos] = items[pos - 1];
		// insert the item
		items[index - 1] = item;
		size++;  // increase the size by 1
	}
	return success;
}

// remove an item at a specified position in the list
void List::remove(int index)
{
	bool success = (index >= 1) && (index <= size);
	if (success)
	{  // delete item by shifting all items at positions >
	   // index toward the beginning of the list
	   // (no shift if index == size)
		for (int fromPosition = index + 1; fromPosition <= size; fromPosition++)
			items[fromPosition - 2] = items[fromPosition - 1];
		size--;  // decrease the size by 1
	}

}

// get an item at a specified position of the list (retrieve)
ItemType List::get(int index)
{
	ItemType item;
	bool success = (index >= 1) && (index <= size);
	if (success)
		return items[index - 1];
	return item;
}

// check if the list is empty
bool List::isEmpty() { return size == 0; }

// check the size of the list
int List::getLength() { return size; }

// display the items in the list
void List::print()
{

	for (int i = 1; i <= getLength(); i++)
	{
		ItemType item = get(i);
		cout << item.getName() << "\t" << item.getTelNo() << endl;
	}

}

// replace the  item in the specified index in the list
void List::replace(int index, ItemType item)
{
	bool success = index >= 1 && index <= getLength();
	if (success)
		items[index - 1] = item;
}

//Search for the item if the item exists
int List::searchForRemove(string userChoiceName , string userChoiceTelNo) {
	//I'll do a for-loop to iterate the search function one by one.
	//I'll learn the different ways to search in the future that is way faster and efficient.
	bool success  = false;
	bool *successPtr;
	successPtr = &success;
	int i = 0;
	int *ptr;
	ptr = &i;
	while ((*ptr) < getLength()){
		try {
			if (items[(*ptr)].getName() == userChoiceName && items[(*ptr)].getTelNo() == userChoiceTelNo) {
				*successPtr = true;
				break;
			}
			else {
				(*ptr)++;
				continue;
			}
		}
		catch (exception ex) {
			cout << "error!" << endl;
		}
	}
	
	if (success == false) {
		cout << "No records found" << endl;
		return ((*ptr) -(*ptr) -1 );
		
	}
	else {
		cout << items[(*ptr)].getName() << endl;
		cout << items[(*ptr)].getTelNo() << endl;
		return (*ptr);		
	}
}
void List::search(string userInput) {
	int i = 0;
	int *ptr;
	ptr = &i;
	for ((*ptr); (*ptr) < getLength(); (*ptr)++) {
		if (userInput == items[(*ptr)].getTelNo()) {
			cout << "The phone number : " + userInput + " belongs to " + items[(*ptr)].getName() << endl;
			break;
		}
	}
	if ((*ptr) == getLength()) {
		cout << "The telephone number with the associated user cannot be found!" << endl;
	}
}